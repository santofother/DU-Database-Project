--Santo Fothergill and Finn Rourke

IF NOT EXISTS(SELECT * FROM sys.databases
	WHERE NAME = N'MoonCheeseDatabaseDM')
	CREATE DATABASE MoonCheeseDatabaseDM
GO

-- Switch to the new database.

USE MoonCheeseDatabaseDM;

-- Drop the existing tables.

IF EXISTS(
	SELECT *
	FROM sys.tables
	WHERE name = N'FACT_SALES'
       )
	DROP TABLE FACT_SALES;


IF EXISTS(
	SELECT *
	FROM sys.tables
	WHERE name = N'DIM_MINE'
       )
	DROP TABLE DIM_MINE;

IF EXISTS(
	SELECT *
	FROM sys.tables
	WHERE name = N'DIM_EQUIPMENT'
       )
	DROP TABLE DIM_EQUIPMENT;

IF EXISTS(
	SELECT *
	FROM sys.tables
	WHERE name = N'DIM_SPACESHIP'
       )
	DROP TABLE DIM_SPACESHIP;

IF EXISTS(
	SELECT *
	FROM sys.tables
	WHERE name = N'DIM_CHEESE'
       )
	DROP TABLE DIM_CHEESE;


IF EXISTS(
	SELECT *
	FROM sys.tables
	WHERE name = N'DIM_CUSTOMER'
       )
	DROP TABLE DIM_CUSTOMER;



IF EXISTS(
	SELECT *
	FROM sys.tables
	WHERE name = N'DIM_DATE'
       )
	DROP TABLE DIM_DATE;


-- Create the tables.

CREATE TABLE DIM_DATE (
	Date_SK				INT CONSTRAINT pk_date_key PRIMARY KEY, 
	Date				DATE,
	FullDate			NCHAR(10), -- Date in MM-DD-YYYY format
	DayOfMonth			INT, -- Day number of Month
	DayName				NVARCHAR(9), -- Monday, Tuesday, etc. 
	DayOfWeek			INT, -- First Day Sunday=1 and Saturday=7
	DayOfWeekInMonth	INT, -- 1st Monday or 2nd Monday in Month
	DayOfWeekInYear		INT,
	DayOfQuarter		INT,
	DayOfYear			INT,
	WeekOfMonth			INT,-- Week Number of Month 
	WeekOfQuarter		INT, -- Week Number of the Quarter
	WeekOfYear			INT,-- Week Number of the Year
	Month				INT, -- Number of the Month 1 to 12.
	MonthName			NVARCHAR(9), -- January, February etc.
	MonthOfQuarter		INT, -- Month Number belongs to Quarter
	Quarter				NCHAR(2),
	QuarterName			NCHAR(2), -- First,Second..
	Year				INT, -- Year value of Date stored in Row
	CYearName			NCHAR(7), -- CY 2017,CY 2018
	FYearName			NCHAR(7), -- CY 2017,CY 2018
	MonthYear			NCHAR(10), -- Jan-2018,Feb-2018
	MMYYYY				INT,
	FirstDayOfMonth		DATE,
	LastDayOfMonth		DATE,
	FirstDayOfQuarter	DATE,
	LastDayOfQuarter	DATE,
	FirstDayOfYear		DATE,
	LastDayOfYear		DATE,
	IsWeekday			BIT, -- 0=Weekend ,1=Weekday,
	IsWeekdayName		NVARCHAR(55), -- Weekend, Weekday
	IsHoliday			BIT, -- 1=National Holiday, 0-Not a National Holiday
	IsHolidayName		NVARCHAR(55), -- National Holiday or Not a National Holiday
	Holiday				NVARCHAR(55), --Name of Holiday in US
	Season				INT, --Number of season 1 (Fall to Summer)
	SeasonName			NVARCHAR(10)
);


CREATE TABLE DIM_CUSTOMER (
	Customer_SK			INT IDENTITY CONSTRAINT pk_customer_key PRIMARY KEY,
	Customer_BK			INT NOT NULL,
	FirstName			NVARCHAR(55) NOT NULL,
	LastName			NVARCHAR(55) NOT NULL,
	LFName				NVARCHAR(125) NOT NULL,
	FLName				NVARCHAR(125) NOT NULL,
	DOB					NVARCHAR(55) NOT NULL,
	PhoneNumber			VARCHAR(55) NOT NULL,
	Email				VARCHAR(55) NOT NULL,
	COUNTRY				NVARCHAR(55) NULL,
	State				NVARCHAR(55) NOT NULL,	
	ZIP					NVARCHAR(55) NOT NULL,
	ADDRESS				NVARCHAR(55) NOT NULL
);


CREATE TABLE DIM_CHEESE (
	Cheese_SK			INT IDENTITY CONSTRAINT pk_Cheese_key PRIMARY KEY,
	Cheese_BK			INT NOT NULL,
	Name				NVARCHAR(55) NOT NULL,
	PricePerKilo		Int NOT NULL,
	Size				Real NOT NULL,
	Weight				Real NOT NULL,
);


CREATE TABLE DIM_SPACESHIP (
	Spaceship_SK		INT IDENTITY CONSTRAINT pk_Spaceship_key PRIMARY KEY,
	Spaceship_BK		INT NOT NULL,
	Cost				Real NOT NULL,
	MaxWeightCapacity	DECIMAL(10,2) NOT NULL,
	MaxSizeCapacity		REAL NOT NULL,
	FuelCostPerTons		Int NOT NULL,
);

CREATE TABLE DIM_EQUIPMENT (
	Equipment_SK		INT IDENTITY CONSTRAINT pk_Equipment_key PRIMARY KEY,
	Equipmentp_BK		INT NOT NULL,
	Name				NVARCHAR(55) NOT NULL,
	Cost				Int NOT NULL,
	MaxDepth			Int NOT NULL,
	Weight				Int NOT NULL,
	WeightCapacity		Int NOT NULL,
	OperatingCostPerKG	Int Not Null, 

);

CREATE TABLE DIM_MINE (
	Mine_SK		INT IDENTITY CONSTRAINT pk_Mine_key PRIMARY KEY,
	Mine_BK		INT NOT NULL,
	Name		NVARCHAR(55) NOT NULL,
	MoonLat		NVARCHAR(55) NOT NULL,
	MoonLon		NVARCHAR(55) NOT NULL,
	Quality		Int NOT NULL,
	Depth		Int Not Null
);


CREATE TABLE FACT_SALES
	(
	OrderID				INT NOT NULL,
	OrderProductID		INT NOT NULL,
	OrderDate			INT CONSTRAINT fk_order_date_key FOREIGN KEY REFERENCES DIM_DATE(Date_SK),
	ShipDate			INT CONSTRAINT fk_ship_date_key FOREIGN KEY REFERENCES DIM_DATE(Date_SK),
	Customer_SK			INT CONSTRAINT fk_customer_key FOREIGN KEY REFERENCES DIM_CUSTOMER(Customer_SK),
	Cheese_SK			INT CONSTRAINT fk_Cheese_key FOREIGN KEY REFERENCES DIM_CHEESE(Cheese_SK), 
	Spaceship_SK		INT CONSTRAINT fk_Spaceship_key FOREIGN KEY REFERENCES DIM_SPACESHIP(Spaceship_SK),
	Mine_SK				INT CONSTRAINT fk_Mine_key FOREIGN KEY REFERENCES DIM_MINE(Mine_SK),
	Equipment_SK		INT CONSTRAINT fk_Equipment_key FOREIGN KEY REFERENCES DIM_EQUIPMENT(Equipment_SK),
	PerKgPrice			MONEY Not Null,
	PerKgCost			MONEY NOT NULL,
	UnitWeight			REAL NOT NULL,
	UnitProfit			MONEY NOT NULL,
	Quantity			INT NOT NULL, 
	Revenue				MONEY NOT NULL,
	Cost				MONEY NOT NULL,
	Profit				MONEY NOT NULL,
	CONSTRAINT pk_fact_order_key PRIMARY KEY(OrderID, OrderProductID, OrderDate, Customer_SK, Cheese_SK, Spaceship_SK, Mine_SK, Equipment_SK)
);




GO
CREATE VIEW DIM_ORDER_DATE AS (
SELECT * FROM DIM_DATE);
GO

CREATE VIEW DIM_SHIP_DATE AS (
SELECT * FROM DIM_DATE);
GO

